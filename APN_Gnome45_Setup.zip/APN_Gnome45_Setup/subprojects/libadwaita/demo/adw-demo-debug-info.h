#pragma once

#include <adwaita.h>

G_BEGIN_DECLS

char *adw_demo_generate_debug_info (void);

G_END_DECLS
