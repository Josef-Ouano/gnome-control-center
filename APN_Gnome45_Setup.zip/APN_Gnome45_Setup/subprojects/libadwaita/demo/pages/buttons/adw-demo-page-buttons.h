#pragma once

#include <adwaita.h>

G_BEGIN_DECLS

#define ADW_TYPE_DEMO_PAGE_BUTTONS (adw_demo_page_buttons_get_type())

G_DECLARE_FINAL_TYPE (AdwDemoPageButtons, adw_demo_page_buttons, ADW, DEMO_PAGE_BUTTONS, AdwBin)

G_END_DECLS
