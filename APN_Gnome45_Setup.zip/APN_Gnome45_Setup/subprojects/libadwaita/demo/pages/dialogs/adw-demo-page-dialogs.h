#pragma once

#include <adwaita.h>

G_BEGIN_DECLS

#define ADW_TYPE_DEMO_PAGE_DIALOGS (adw_demo_page_dialogs_get_type())

G_DECLARE_FINAL_TYPE (AdwDemoPageDialogs, adw_demo_page_dialogs, ADW, DEMO_PAGE_DIALOGS, AdwBin)

G_END_DECLS
