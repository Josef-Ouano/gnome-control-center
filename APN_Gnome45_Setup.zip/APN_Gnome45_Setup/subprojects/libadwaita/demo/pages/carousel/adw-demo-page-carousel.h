#pragma once

#include <adwaita.h>

G_BEGIN_DECLS

#define ADW_TYPE_DEMO_PAGE_CAROUSEL (adw_demo_page_carousel_get_type())

G_DECLARE_FINAL_TYPE (AdwDemoPageCarousel, adw_demo_page_carousel, ADW, DEMO_PAGE_CAROUSEL, AdwBin)

G_END_DECLS
