#pragma once

#include <adwaita.h>

G_BEGIN_DECLS

#define ADW_TYPE_DEMO_PAGE_ANIMATIONS (adw_demo_page_animations_get_type())

G_DECLARE_FINAL_TYPE (AdwDemoPageAnimations, adw_demo_page_animations, ADW, DEMO_PAGE_ANIMATIONS, AdwBin)

G_END_DECLS
