#pragma once

#include <adwaita.h>

G_BEGIN_DECLS

#define ADW_TYPE_DEMO_PAGE_WELCOME (adw_demo_page_welcome_get_type())

G_DECLARE_FINAL_TYPE (AdwDemoPageWelcome, adw_demo_page_welcome, ADW, DEMO_PAGE_WELCOME, AdwBin)

G_END_DECLS
