#pragma once

#include <adwaita.h>

G_BEGIN_DECLS

#define ADW_TYPE_DEMO_PAGE_AVATAR (adw_demo_page_avatar_get_type())

G_DECLARE_FINAL_TYPE (AdwDemoPageAvatar, adw_demo_page_avatar, ADW, DEMO_PAGE_AVATAR, AdwBin)

G_END_DECLS
