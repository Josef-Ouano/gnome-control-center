#pragma once

#include <adwaita.h>

G_BEGIN_DECLS

#define ADW_TYPE_DEMO_PAGE_SPLIT_VIEWS (adw_demo_page_split_views_get_type())

G_DECLARE_FINAL_TYPE (AdwDemoPageSplitViews, adw_demo_page_split_views, ADW, DEMO_PAGE_SPLIT_VIEWS, AdwBin)

G_END_DECLS
