#pragma once

#include <adwaita.h>

G_BEGIN_DECLS

#define ADW_TYPE_DEMO_PAGE_BANNERS (adw_demo_page_banners_get_type())

G_DECLARE_FINAL_TYPE (AdwDemoPageBanners, adw_demo_page_banners, ADW, DEMO_PAGE_BANNERS, AdwBin)

G_END_DECLS
