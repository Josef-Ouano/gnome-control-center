#! /bin/bash

echo "installing gnome-45 dependencies"

sudo apt install meson build-essential -y &&
sudo apt install libpulse-dev -y &&
sudo apt install libglib2.0-dev -y &&
sudo apt install cmake -y &&
sudo apt install libxkbcommon-dev -y &&
sudo apt install libcairo2-dev -y &&
sudo apt-get install -y libxml2-dev -y &&
sudo apt-get install libwayland-bin -y &&
sudo apt-get install libxrandr-dev -y &&
sudo apt-get install libxi-dev -y &&
sudo apt-get install libxcursor-dev -y &&
sudo apt-get install libxdamage-dev -y &&
sudo apt-get install libxinerama-dev -y &&
sudo apt-get install python3-dev -y &&
sudo apt-get install flex -y &&
sudo apt-get install bison -y &&
sudo apt-get install gettext -y &&
sudo apt install libcurl4-openssl-dev -y &&
sudo apt-get install libgstreamer1.0-dev libgstreamer-plugins-base1.0-dev libgstreamer-plugins-bad1.0-dev gstreamer1.0-plugins-base gstreamer1.0-plugins-good gstreamer1.0-plugins-bad gstreamer1.0-plugins-ugly gstreamer1.0-libav gstreamer1.0-tools gstreamer1.0-x gstreamer1.0-alsa gstreamer1.0-gl gstreamer1.0-gtk3 gstreamer1.0-qt5 gstreamer1.0-pulseaudio -y &&
sudo apt install libyaml-dev -y &&
sudo apt-get install libstemmer-dev -y &&
sudo apt-get install itstool -y &&
sudo apt-get install xsltproc -y &&
sudo apt-get install libaccountsservice-dev -y &&
sudo apt-get install libcolord-dev -y &&
sudo apt-get install libgnome-desktop-4-dev -y &&
sudo apt-get install libgnome-bg-4-dev -y &&
sudo apt-get install libgnome-rr-4-dev -y &&
sudo apt-get install -y gnome-settings-daemon-dev -y &&
sudo apt-get install libgoa-1.0-dev -y &&
sudo apt-get install libupower-glib-dev -y &&
sudo apt-get install libgcr-3-dev -y &&
sudo apt-get install libpwquality-dev -y &&
sudo apt-get install libcups2-dev -y &&
sudo apt-get install libibus-1.0-dev -y &&
sudo apt-get install libmm-glib-dev -y &&
sudo apt-get install libnm-dev -y &&
sudo apt-get install libnma-gtk4-dev -y &&
sudo apt-get install libgnome-bluetooth-ui-3.0-dev -y &&
sudo apt-get install libwacom-dev -y &&
sudo apt-get install libcolord-gtk4-dev -y &&
sudo apt-get install libudisks2-dev -y &&
sudo apt-get install libgtop2-dev -y &&
sudo apt-get install libgoa-backend-1.0-dev -y &&
sudo apt-get install libsmbclient-dev -y &&
sudo apt-get install libsecret-1-dev -y &&
sudo apt-get install gnutls-bin -y &&
sudo apt-get install gnutls-dev -y &&
sudo apt-get install libgsound-dev -y &&
sudo apt-get install libkrb5-dev -y &&
sudo apt-get install gperf -y &&
sudo apt-get install libjson-glib-dev -y &&
sudo apt-get install libsoup-3.0-dev &&
sudo apt-get install libgcr-4-dev -y &&

echo "Done installing gnome-45 dependencies"	
